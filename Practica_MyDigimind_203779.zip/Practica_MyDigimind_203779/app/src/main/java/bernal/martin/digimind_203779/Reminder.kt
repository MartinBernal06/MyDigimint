package bernal.martin.digimind_203779

import java.io.Serializable

data class Reminder (
    var days : String,
    var time : String,
    var name : String
): Serializable